# ifndef ARDUINO
# define ARDUINO 105 /* only for slsp */
# include <Arduino.h>
# endif

# include "Wire.cpp"
# include "twi.c"
# include "Adafruit_MotorShield.cpp"
# include "Adafruit_PWMServoDriver.cpp"

Adafruit_MotorShield AFMS_DC = Adafruit_MotorShield();
Adafruit_MotorShield AFMS_ST = Adafruit_MotorShield();

Adafruit_DCMotor *dcm1 = AFMS_DC.getMotor(1);
Adafruit_DCMotor *dcm2 = AFMS_DC.getMotor(2);
Adafruit_DCMotor *dcm3 = AFMS_DC.getMotor(3);
Adafruit_DCMotor *dcm4 = AFMS_DC.getMotor(4);

Adafruit_StepperMotor *stm1 = AFMS_ST.getStepper(200, 1);
Adafruit_StepperMotor *stm2 = AFMS_ST.getStepper(200, 2);
    
extern "C" void dcm_init() {
    AFMS_DC.begin();
}

extern "C" void dcm_output(double dcm, double dir, double spd) {
    if (dcm==1) {
        dcm1->setSpeed(spd);
        if (dir>0) dcm1->run(FORWARD);
        if (dir<0) dcm1->run(BACKWARD);
        if (dir==0) dcm1->run(RELEASE);
    }

    if (dcm==2) {
        dcm2->setSpeed(spd);
        if (dir>0) dcm2->run(FORWARD);
        if (dir<0) dcm2->run(BACKWARD);
        if (dir==0) dcm2->run(RELEASE);
    }
    
    if (dcm==3) {
        dcm3->setSpeed(spd);
        if (dir>0) dcm3->run(FORWARD);
        if (dir<0) dcm3->run(BACKWARD);
        if (dir==0) dcm3->run(RELEASE);
    }

    if (dcm==4) {
        dcm4->setSpeed(spd);
        if (dir>0) dcm4->run(FORWARD);
        if (dir<0) dcm4->run(BACKWARD);
        if (dir==0) dcm4->run(RELEASE);
    }
}

extern "C" void stm_init() {
    AFMS_ST.begin();
}

extern "C" void stm_output(double stm, double stp, double dir, double spd, double sty) {
    if (stm==1) {
        stm1->setSpeed(spd);
        if (dir>0) stm1->step(stp,FORWARD,sty);
        if (dir<0) stm1->step(stp,BACKWARD,sty);
        if (dir==0) stm1->release();
    }

    if (stm==2) {
        stm2->setSpeed(spd);
        if (dir>0) stm2->step(stp,FORWARD,sty);
        if (dir<0) stm2->step(stp,BACKWARD,sty);
        if (dir==0) stm2->release();
    }
}