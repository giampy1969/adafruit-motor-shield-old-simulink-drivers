# ifndef ARDUINO
# define ARDUINO 105 /* only for slsp */
# include <Arduino.h>
# endif

# include "AFMotor.cpp"

AF_DCMotor dcm1(1, MOTOR12_64KHZ); /* dc motor #1, 64KHz pwm */
AF_DCMotor dcm2(2, MOTOR12_64KHZ); /* dc motor #1, 64KHz pwm */
AF_DCMotor dcm3(3, MOTOR12_64KHZ); /* dc motor #1, 64KHz pwm */
AF_DCMotor dcm4(4, MOTOR12_64KHZ); /* dc motor #1, 64KHz pwm */

AF_Stepper stm1(200, 1);
AF_Stepper stm2(200, 2);

extern "C" void dcm_output(double dcm, double dir, double spd) {
    if (dcm==1) {
        dcm1.setSpeed(spd);
        if (dir>0) dcm1.run(FORWARD);
        if (dir<0) dcm1.run(BACKWARD);
        if (dir==0) dcm1.run(RELEASE);
    }

    if (dcm==2) {
        dcm2.setSpeed(spd);
        if (dir>0) dcm2.run(FORWARD);
        if (dir<0) dcm2.run(BACKWARD);
        if (dir==0) dcm2.run(RELEASE);
    }
    
    if (dcm==3) {
        dcm3.setSpeed(spd);
        if (dir>0) dcm3.run(FORWARD);
        if (dir<0) dcm3.run(BACKWARD);
        if (dir==0) dcm3.run(RELEASE);
    }

    if (dcm==4) {
        dcm4.setSpeed(spd);
        if (dir>0) dcm4.run(FORWARD);
        if (dir<0) dcm4.run(BACKWARD);
        if (dir==0) dcm4.run(RELEASE);
    }
}

extern "C" void stm_output(double stm, double stp, double dir, double spd, double style) {
    if (stm==1) {
        stm1.setSpeed(spd);
        if (dir>0) stm1.step(stp,FORWARD,style);
        if (dir<0) stm1.step(stp,BACKWARD,style);
        if (dir==0) stm1.release();
    }

    if (stm==2) {
        stm2.setSpeed(spd);
        if (dir>0) stm2.step(stp,FORWARD,style);
        if (dir<0) stm2.step(stp,BACKWARD,style);
        if (dir==0) stm2.release();
    }
}