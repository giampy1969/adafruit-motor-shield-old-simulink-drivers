#include <Arduino.h>

void arms_ab_init(char prt) {
    
    /* set direction, speed and brake pins for port A as output */ 
    if (prt==1) {
        pinMode(12,OUTPUT);
        pinMode(3,OUTPUT);
        pinMode(9,OUTPUT);
    }

    /* set direction, speed and brake pins for port B as output */ 
    if (prt==2) {
        pinMode(13,OUTPUT);
        pinMode(11,OUTPUT);
        pinMode(8,OUTPUT);
    }
    
}

void arms_ab_output(char prt, char dir, char spd, char brk) {
    
    /* set direction, speed and brake values for port A */ 
    if (prt==1) {
        digitalWrite(12,dir);
        analogWrite(3,spd);
        digitalWrite(9,brk);
    }

    /* set direction, speed and brake values for port B */ 
    if (prt==2) {
        digitalWrite(13,dir);
        analogWrite(11,spd);
        digitalWrite(8,brk);
    }
}

